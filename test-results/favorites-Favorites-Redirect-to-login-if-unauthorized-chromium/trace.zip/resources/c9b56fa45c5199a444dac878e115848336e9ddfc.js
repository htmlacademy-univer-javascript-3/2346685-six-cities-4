import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cards/regular/offer-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=010e9a4f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=44ea9219";
import { getStarsFromRating } from "/src/constant/utils.ts";
import { useAppDispatch, useAppSelector } from "/src/hooks/index.ts";
import { fetchOfferByIDAction, setOfferFavoriteStatusAction } from "/src/store/api-actions.ts";
import { getAuthStatus } from "/src/store/user-reducer/selectors.ts";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=010e9a4f"; const useState = __vite__cjsImport8_react["useState"];
import { AuthStatus } from "/src/constant/consts.ts";
export default function OfferCard({
  offer,
  onMouseOver,
  isMainScreen
}) {
  _s();
  const dispatch = useAppDispatch();
  const authStatus = useAppSelector(getAuthStatus);
  const [isFavoriteOffer, setFavoriteOffer] = useState(offer.isFavorite);
  const handleFavoriteButtonClick = () => {
    if (authStatus !== AuthStatus.Auth) {
      return;
    }
    dispatch(setOfferFavoriteStatusAction({
      id: offer.id,
      favoriteStatus: !isFavoriteOffer
    }));
    setFavoriteOffer(!isFavoriteOffer);
  };
  return /* @__PURE__ */ jsxDEV("article", { className: isMainScreen ? "cities__card place-card" : "near-places__card place-card", id: offer.id.toString(), onMouseOver: (evt) => {
    const target = evt.currentTarget;
    onMouseOver(target.id);
  }, children: [
    offer.isPremium && isMainScreen ? /* @__PURE__ */ jsxDEV("div", { className: "place-card__mark", children: /* @__PURE__ */ jsxDEV("span", { children: "Premium" }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
      lineNumber: 39,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
      lineNumber: 38,
      columnNumber: 42
    }, this) : "",
    /* @__PURE__ */ jsxDEV("div", { className: isMainScreen ? "near-places__image-wrapper place-card__image-wrapper" : "cities__image-wrapper place-card__image-wrapper", children: /* @__PURE__ */ jsxDEV(Link, { to: `/offer/${offer.id}`, state: offer, onClick: () => {
      dispatch(fetchOfferByIDAction({
        id: offer.id
      }));
    }, children: /* @__PURE__ */ jsxDEV("img", { className: "place-card__image", src: offer.previewImage, width: "260", height: "200", alt: "Place image" }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
      lineNumber: 47,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
      lineNumber: 42,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "place-card__info", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "place-card__price-wrapper", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "place-card__price", children: [
          /* @__PURE__ */ jsxDEV("b", { className: "place-card__price-value", children: [
            "€",
            offer.price
          ] }, void 0, true, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
            lineNumber: 53,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "place-card__price-text", children: "/ night" }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
            lineNumber: 54,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: `place-card__bookmark-button ${isFavoriteOffer ? "place-card__bookmark-button--active" : ""} button`, onClick: handleFavoriteButtonClick, type: "button", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "place-card__bookmark-icon", width: "18", height: "19", children: /* @__PURE__ */ jsxDEV("use", { xlinkHref: "#icon-bookmark" }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
            lineNumber: 58,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
            lineNumber: 57,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "visually-hidden", children: "To bookmarks" }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
            lineNumber: 60,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
          lineNumber: 56,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "place-card__rating rating", children: /* @__PURE__ */ jsxDEV("div", { className: "place-card__stars rating__stars", children: [
        /* @__PURE__ */ jsxDEV("span", { style: {
          width: getStarsFromRating(offer.rating)
        } }, void 0, false, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
          lineNumber: 65,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "visually-hidden", children: "Rating" }, void 0, false, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
          lineNumber: 68,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
        lineNumber: 64,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "place-card__name", children: /* @__PURE__ */ jsxDEV(Link, { to: `/offer/${offer.id}`, state: offer, children: offer.title }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
        lineNumber: 72,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "place-card__type", children: offer.type }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
        lineNumber: 74,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
}
_s(OfferCard, "0dVx5SF5KXxbLSCBtLiR/vXUQ0U=", false, function() {
  return [useAppDispatch, useAppSelector];
});
_c = OfferCard;
var _c;
$RefreshReg$(_c, "OfferCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/rubco/2346685-six-cities-4/src/components/cards/regular/offer-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZDWixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0JDLHNCQUFzQjtBQUMvQyxTQUFTQyxzQkFBc0JDLG9DQUFvQztBQUNuRSxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGtCQUFrQjtBQVEzQix3QkFBd0JDLFVBQVU7QUFBQSxFQUFFQztBQUFBQSxFQUFPQztBQUFBQSxFQUFhQztBQUE4QixHQUFnQjtBQUFBQyxLQUFBO0FBQ3BHLFFBQU1DLFdBQVdaLGVBQWU7QUFFaEMsUUFBTWEsYUFBYVosZUFBZUcsYUFBYTtBQUMvQyxRQUFNLENBQUNVLGlCQUFpQkMsZ0JBQWdCLElBQUlWLFNBQXlCRyxNQUFNUSxVQUFVO0FBRXJGLFFBQU1DLDRCQUE0QkEsTUFBTTtBQUN0QyxRQUFHSixlQUFlUCxXQUFXWSxNQUFNO0FBQ2pDO0FBQUEsSUFDRjtBQUNBTixhQUFTVCw2QkFBNkI7QUFBQSxNQUFDZ0IsSUFBSVgsTUFBTVc7QUFBQUEsTUFBSUMsZ0JBQWdCLENBQUNOO0FBQUFBLElBQWUsQ0FBQyxDQUFDO0FBQ3ZGQyxxQkFBaUIsQ0FBQ0QsZUFBZTtBQUFBLEVBQ25DO0FBRUEsU0FDRSx1QkFBQyxhQUFRLFdBQVdKLGVBQWUsNEJBQTRCLGdDQUM3RCxJQUFJRixNQUFNVyxHQUFHRSxTQUFTLEdBQ3RCLGFBQWNDLFNBQVE7QUFDcEIsVUFBTUMsU0FBU0QsSUFBSUU7QUFDbkJmLGdCQUFZYyxPQUFPSixFQUFFO0FBQUEsRUFDdkIsR0FHR1g7QUFBQUEsVUFBTWlCLGFBQWFmLGVBQ2xCLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxVQUFLLHVCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYSxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUNHO0FBQUEsSUFFUCx1QkFBQyxTQUFJLFdBQVdBLGVBQWUseURBQXlELG1EQUN0RixpQ0FBQyxRQUFLLElBQUssVUFBU0YsTUFBTVcsRUFBRyxJQUFHLE9BQU9YLE9BQU8sU0FBUyxNQUFNO0FBQzNESSxlQUFTVixxQkFBcUI7QUFBQSxRQUFDaUIsSUFBSVgsTUFBTVc7QUFBQUEsTUFBRSxDQUFDLENBQUM7QUFBQSxJQUMvQyxHQUVFLGlDQUFDLFNBQUksV0FBVSxxQkFBb0IsS0FBS1gsTUFBTWtCLGNBQWMsT0FBTSxPQUFNLFFBQU8sT0FBTSxLQUFJLGlCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNHLEtBSnhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsWUFBT2xCLE1BQU1tQjtBQUFBQSxlQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFELHVCQUFDLFVBQUssV0FBVSwwQkFBeUIsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsYUFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFdBQVksK0JBQThCYixrQkFBa0Isd0NBQXdDLEVBQUcsV0FBVSxTQUFTRywyQkFBMkIsTUFBSyxVQUNoSztBQUFBLGlDQUFDLFNBQUksV0FBVSw2QkFBNEIsT0FBTSxNQUFLLFFBQU8sTUFDM0QsaUNBQUMsU0FBSSxXQUFVLG9CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxtQkFBa0IsNEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsYUFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSwrQkFBQyxVQUFLLE9BQU87QUFBQSxVQUFFVyxPQUFPN0IsbUJBQW1CUyxNQUFNcUIsTUFBTTtBQUFBLFFBQUUsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFFBQzFELHVCQUFDLFVBQUssV0FBVSxtQkFBa0Isc0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxXQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSxvQkFDWixpQ0FBQyxRQUFLLElBQUssVUFBU3JCLE1BQU1XLEVBQUcsSUFBRyxPQUFPWCxPQUFRQSxnQkFBTXNCLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsb0JBQW9CdEIsZ0JBQU11QixRQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRDO0FBQUEsU0F0QjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxPQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBO0FBRUo7QUFBQ3BCLEdBL0R1QkosV0FBUztBQUFBLFVBQ2RQLGdCQUVFQyxjQUFjO0FBQUE7QUFBQStCLEtBSFh6QjtBQUFTLElBQUF5QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTGluayIsImdldFN0YXJzRnJvbVJhdGluZyIsInVzZUFwcERpc3BhdGNoIiwidXNlQXBwU2VsZWN0b3IiLCJmZXRjaE9mZmVyQnlJREFjdGlvbiIsInNldE9mZmVyRmF2b3JpdGVTdGF0dXNBY3Rpb24iLCJnZXRBdXRoU3RhdHVzIiwidXNlU3RhdGUiLCJBdXRoU3RhdHVzIiwiT2ZmZXJDYXJkIiwib2ZmZXIiLCJvbk1vdXNlT3ZlciIsImlzTWFpblNjcmVlbiIsIl9zIiwiZGlzcGF0Y2giLCJhdXRoU3RhdHVzIiwiaXNGYXZvcml0ZU9mZmVyIiwic2V0RmF2b3JpdGVPZmZlciIsImlzRmF2b3JpdGUiLCJoYW5kbGVGYXZvcml0ZUJ1dHRvbkNsaWNrIiwiQXV0aCIsImlkIiwiZmF2b3JpdGVTdGF0dXMiLCJ0b1N0cmluZyIsImV2dCIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJpc1ByZW1pdW0iLCJwcmV2aWV3SW1hZ2UiLCJwcmljZSIsIndpZHRoIiwicmF0aW5nIiwidGl0bGUiLCJ0eXBlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJvZmZlci1jYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPZmZlclR5cGUgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudC90eXBlcyc7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBnZXRTdGFyc0Zyb21SYXRpbmcgfSBmcm9tICcuLi8uLi8uLi9jb25zdGFudC91dGlscyc7XG5pbXBvcnQgeyB1c2VBcHBEaXNwYXRjaCwgdXNlQXBwU2VsZWN0b3IgfSBmcm9tICcuLi8uLi8uLi9ob29rcyc7XG5pbXBvcnQgeyBmZXRjaE9mZmVyQnlJREFjdGlvbiwgc2V0T2ZmZXJGYXZvcml0ZVN0YXR1c0FjdGlvbiB9IGZyb20gJy4uLy4uLy4uL3N0b3JlL2FwaS1hY3Rpb25zJztcbmltcG9ydCB7IGdldEF1dGhTdGF0dXMgfSBmcm9tICcuLi8uLi8uLi9zdG9yZS91c2VyLXJlZHVjZXIvc2VsZWN0b3JzJztcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQXV0aFN0YXR1cyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50L2NvbnN0cyc7XG5cbmV4cG9ydCB0eXBlIE9mZmVyQ2FyZFBhcmFtcyA9IHtcbiAgb2ZmZXI6IE9mZmVyVHlwZTtcbiAgb25Nb3VzZU92ZXI6IChpZDogc3RyaW5nKSA9PiB2b2lkO1xuICBpc01haW5TY3JlZW46IGJvb2xlYW47XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE9mZmVyQ2FyZCh7IG9mZmVyLCBvbk1vdXNlT3ZlciwgaXNNYWluU2NyZWVuIH06IE9mZmVyQ2FyZFBhcmFtcyk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VBcHBEaXNwYXRjaCgpO1xuXG4gIGNvbnN0IGF1dGhTdGF0dXMgPSB1c2VBcHBTZWxlY3RvcihnZXRBdXRoU3RhdHVzKTtcbiAgY29uc3QgW2lzRmF2b3JpdGVPZmZlciwgc2V0RmF2b3JpdGVPZmZlcl0gPSB1c2VTdGF0ZTxib29sZWFuIHwgbnVsbD4ob2ZmZXIuaXNGYXZvcml0ZSk7XG5cbiAgY29uc3QgaGFuZGxlRmF2b3JpdGVCdXR0b25DbGljayA9ICgpID0+IHtcbiAgICBpZihhdXRoU3RhdHVzICE9PSBBdXRoU3RhdHVzLkF1dGgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZGlzcGF0Y2goc2V0T2ZmZXJGYXZvcml0ZVN0YXR1c0FjdGlvbih7aWQ6IG9mZmVyLmlkLCBmYXZvcml0ZVN0YXR1czogIWlzRmF2b3JpdGVPZmZlcn0pKTtcbiAgICBzZXRGYXZvcml0ZU9mZmVyKCFpc0Zhdm9yaXRlT2ZmZXIpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPXtpc01haW5TY3JlZW4gPyAnY2l0aWVzX19jYXJkIHBsYWNlLWNhcmQnIDogJ25lYXItcGxhY2VzX19jYXJkIHBsYWNlLWNhcmQnfVxuICAgICAgaWQ9e29mZmVyLmlkLnRvU3RyaW5nKCl9XG4gICAgICBvbk1vdXNlT3Zlcj17KGV2dCkgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldnQuY3VycmVudFRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgICAgb25Nb3VzZU92ZXIodGFyZ2V0LmlkKTtcbiAgICAgIH19XG4gICAgPlxuICAgICAge1xuICAgICAgICAob2ZmZXIuaXNQcmVtaXVtICYmIGlzTWFpblNjcmVlbikgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19tYXJrXCI+XG4gICAgICAgICAgICA8c3Bhbj5QcmVtaXVtPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKCcnKVxuICAgICAgfVxuICAgICAgPGRpdiBjbGFzc05hbWU9e2lzTWFpblNjcmVlbiA/ICduZWFyLXBsYWNlc19faW1hZ2Utd3JhcHBlciBwbGFjZS1jYXJkX19pbWFnZS13cmFwcGVyJyA6ICdjaXRpZXNfX2ltYWdlLXdyYXBwZXIgcGxhY2UtY2FyZF9faW1hZ2Utd3JhcHBlcid9PlxuICAgICAgICA8TGluayB0bz17YC9vZmZlci8ke29mZmVyLmlkfWB9IHN0YXRlPXtvZmZlcn0gb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgIGRpc3BhdGNoKGZldGNoT2ZmZXJCeUlEQWN0aW9uKHtpZCA6b2ZmZXIuaWR9KSk7XG4gICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8aW1nIGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX2ltYWdlXCIgc3JjPXtvZmZlci5wcmV2aWV3SW1hZ2V9IHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjAwXCIgYWx0PVwiUGxhY2UgaW1hZ2VcIiAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxhY2UtY2FyZF9faW5mb1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX3ByaWNlLXdyYXBwZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX3ByaWNlXCI+XG4gICAgICAgICAgICA8YiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19wcmljZS12YWx1ZVwiPiZldXJvO3tvZmZlci5wcmljZX08L2I+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19wcmljZS10ZXh0XCI+JiM0NzsmbmJzcDtuaWdodDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YHBsYWNlLWNhcmRfX2Jvb2ttYXJrLWJ1dHRvbiAke2lzRmF2b3JpdGVPZmZlciA/ICdwbGFjZS1jYXJkX19ib29rbWFyay1idXR0b24tLWFjdGl2ZScgOiAnJ30gYnV0dG9uYH0gb25DbGljaz17aGFuZGxlRmF2b3JpdGVCdXR0b25DbGlja30gdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19ib29rbWFyay1pY29uXCIgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE5XCI+XG4gICAgICAgICAgICAgIDx1c2UgeGxpbmtIcmVmPVwiI2ljb24tYm9va21hcmtcIj48L3VzZT5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmlzdWFsbHktaGlkZGVuXCI+VG8gYm9va21hcmtzPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19yYXRpbmcgcmF0aW5nXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19zdGFycyByYXRpbmdfX3N0YXJzXCI+XG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogZ2V0U3RhcnNGcm9tUmF0aW5nKG9mZmVyLnJhdGluZykgfX0+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmlzdWFsbHktaGlkZGVuXCI+UmF0aW5nPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX25hbWVcIj5cbiAgICAgICAgICA8TGluayB0bz17YC9vZmZlci8ke29mZmVyLmlkfWB9IHN0YXRlPXtvZmZlcn0+e29mZmVyLnRpdGxlfTwvTGluaz5cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicGxhY2UtY2FyZF9fdHlwZVwiPntvZmZlci50eXBlfTwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvYXJ0aWNsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnViY28vMjM0NjY4NS1zaXgtY2l0aWVzLTQvc3JjL2NvbXBvbmVudHMvY2FyZHMvcmVndWxhci9vZmZlci1jYXJkLnRzeCJ9