import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/review.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=010e9a4f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/rubco/2346685-six-cities-4/src/components/review.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { getStarsFromRating } from "/src/constant/utils.ts";
export default function Review({
  review
}) {
  const {
    date,
    rating,
    id,
    user,
    comment
  } = review;
  return /* @__PURE__ */ jsxDEV("li", { className: "reviews__item", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "reviews__user user", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "reviews__avatar-wrapper user__avatar-wrapper", children: /* @__PURE__ */ jsxDEV("img", { className: "reviews__avatar user__avatar", src: user.avatarUrl, width: "54", height: "54", alt: "Reviews avatar" }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 19,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "reviews__user-name", children: user.name }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "reviews__info", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "reviews__rating rating", children: /* @__PURE__ */ jsxDEV("div", { className: "reviews__stars rating__stars", children: [
        /* @__PURE__ */ jsxDEV("span", { style: {
          width: getStarsFromRating(rating)
        } }, void 0, false, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
          lineNumber: 28,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "visually-hidden", children: "Rating" }, void 0, false, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
          lineNumber: 31,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 27,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "reviews__text", children: comment }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("time", { className: "reviews__time", dateTime: date, children: date }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, id, true, {
    fileName: "/home/rubco/2346685-six-cities-4/src/components/review.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
}
_c = Review;
var _c;
$RefreshReg$(_c, "Review");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/rubco/2346685-six-cities-4/src/components/review.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVU7QUFiViwyQkFBMkI7QUFBQSxNQUFtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzlDLFNBQVNBLDBCQUEwQjtBQU1uQyx3QkFBd0JDLE9BQU87QUFBQSxFQUFDQztBQUFtQixHQUFnQjtBQUNqRSxRQUFNO0FBQUEsSUFBQ0M7QUFBQUEsSUFBTUM7QUFBQUEsSUFBUUM7QUFBQUEsSUFBSUM7QUFBQUEsSUFBTUM7QUFBQUEsRUFBTyxJQUFJTDtBQUMxQyxTQUNFLHVCQUFDLFFBQUcsV0FBVSxpQkFDWjtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnREFDYixpQ0FBQyxTQUFJLFdBQVUsZ0NBQStCLEtBQUtJLEtBQUtFLFdBQVcsT0FBTSxNQUFLLFFBQU8sTUFBSyxLQUFJLG9CQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThHLEtBRGhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLHNCQUNiRixlQUFLRyxRQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMEJBQ2IsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsVUFBSyxPQUFPO0FBQUEsVUFBQ0MsT0FBT1YsbUJBQW1CSSxNQUFNO0FBQUEsUUFBQyxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsVUFBSyxXQUFVLG1CQUFrQixzQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFdBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGlCQUNWRyxxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsVUFBVUosTUFBT0Esa0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxTQVZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxPQXBCaUNFLElBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQkE7QUFFSjtBQUFDTSxLQTFCdUJWO0FBQU0sSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImdldFN0YXJzRnJvbVJhdGluZyIsIlJldmlldyIsInJldmlldyIsImRhdGUiLCJyYXRpbmciLCJpZCIsInVzZXIiLCJjb21tZW50IiwiYXZhdGFyVXJsIiwibmFtZSIsIndpZHRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJyZXZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJldmlld1R5cGUgfSBmcm9tICcuLi9jb25zdGFudC90eXBlcyc7XG5pbXBvcnQgeyBnZXRTdGFyc0Zyb21SYXRpbmcgfSBmcm9tICcuLi9jb25zdGFudC91dGlscyc7XG5cbnR5cGUgUmV2aWV3UHJvcHMgPSB7XG4gICAgcmV2aWV3OiBSZXZpZXdUeXBlO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXZpZXcoe3Jldmlld306IFJldmlld1Byb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCB7ZGF0ZSwgcmF0aW5nLCBpZCwgdXNlciwgY29tbWVudH0gPSByZXZpZXc7XG4gIHJldHVybiAoXG4gICAgPGxpIGNsYXNzTmFtZT1cInJldmlld3NfX2l0ZW1cIiBrZXk9e2lkfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3c19fdXNlciB1c2VyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3c19fYXZhdGFyLXdyYXBwZXIgdXNlcl9fYXZhdGFyLXdyYXBwZXJcIj5cbiAgICAgICAgICA8aW1nIGNsYXNzTmFtZT1cInJldmlld3NfX2F2YXRhciB1c2VyX19hdmF0YXJcIiBzcmM9e3VzZXIuYXZhdGFyVXJsfSB3aWR0aD1cIjU0XCIgaGVpZ2h0PVwiNTRcIiBhbHQ9XCJSZXZpZXdzIGF2YXRhclwiLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJldmlld3NfX3VzZXItbmFtZVwiPlxuICAgICAgICAgIHt1c2VyLm5hbWV9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXdzX19pbmZvXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3c19fcmF0aW5nIHJhdGluZ1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3c19fc3RhcnMgcmF0aW5nX19zdGFyc1wiPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3t3aWR0aDogZ2V0U3RhcnNGcm9tUmF0aW5nKHJhdGluZyl9fT48L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2aXN1YWxseS1oaWRkZW5cIj5SYXRpbmc8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJyZXZpZXdzX190ZXh0XCI+XG4gICAgICAgICAge2NvbW1lbnR9XG4gICAgICAgIDwvcD5cbiAgICAgICAgPHRpbWUgY2xhc3NOYW1lPVwicmV2aWV3c19fdGltZVwiIGRhdGVUaW1lPXtkYXRlfT57ZGF0ZX08L3RpbWU+XG4gICAgICA8L2Rpdj5cbiAgICA8L2xpPlxuICApO1xufVxuIl0sImZpbGUiOiIvaG9tZS9ydWJjby8yMzQ2Njg1LXNpeC1jaXRpZXMtNC9zcmMvY29tcG9uZW50cy9yZXZpZXcudHN4In0=