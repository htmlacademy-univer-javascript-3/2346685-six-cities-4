import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cards/favorite/favorite-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=010e9a4f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=44ea9219";
import { getStarsFromRating } from "/src/constant/utils.ts";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=010e9a4f"; const useState = __vite__cjsImport5_react["useState"];
import { setOfferFavoriteStatusAction } from "/src/store/api-actions.ts";
import { useAppDispatch } from "/src/hooks/index.ts";
export default function FavoriteCard({
  offer
}) {
  _s();
  const dispatch = useAppDispatch();
  const [isFavoriteOffer, setFavoriteOffer] = useState(offer.isFavorite);
  const handleFavoriteButtonClick = () => {
    dispatch(setOfferFavoriteStatusAction({
      id: offer.id,
      favoriteStatus: !isFavoriteOffer
    }));
    setFavoriteOffer(!isFavoriteOffer);
  };
  return /* @__PURE__ */ jsxDEV("article", { className: "favorites__card place-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "favorites__image-wrapper place-card__image-wrapper", children: /* @__PURE__ */ jsxDEV(Link, { to: `/offer/${offer.id}`, state: offer, children: /* @__PURE__ */ jsxDEV("img", { className: "place-card__image", src: offer.previewImage, width: "260", height: "200", alt: "Place image" }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
      lineNumber: 27,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
      lineNumber: 26,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "favorites__card-info place-card__info", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "place-card__price-wrapper", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "place-card__price", children: [
          /* @__PURE__ */ jsxDEV("b", { className: "place-card__price-value", children: [
            "€",
            offer.price
          ] }, void 0, true, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
            lineNumber: 33,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "place-card__price-text", children: "/ night" }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
            lineNumber: 34,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
          lineNumber: 32,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: `place-card__bookmark-button ${isFavoriteOffer ? "place-card__bookmark-button--active" : ""} button`, onClick: handleFavoriteButtonClick, type: "button", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "place-card__bookmark-icon", width: "18", height: "19", children: /* @__PURE__ */ jsxDEV("use", { xlinkHref: "#icon-bookmark" }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
            lineNumber: 38,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
            lineNumber: 37,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "visually-hidden", children: "In bookmarks" }, void 0, false, {
            fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
            lineNumber: 40,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
          lineNumber: 36,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "place-card__rating rating", children: /* @__PURE__ */ jsxDEV("div", { className: "place-card__stars rating__stars", children: [
        /* @__PURE__ */ jsxDEV("span", { style: {
          width: getStarsFromRating(offer.rating)
        } }, void 0, false, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
          lineNumber: 45,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "visually-hidden", children: "Rating" }, void 0, false, {
          fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
          lineNumber: 48,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
        lineNumber: 44,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "place-card__name", children: /* @__PURE__ */ jsxDEV(Link, { to: `/offer/${offer.id}`, state: offer, children: offer.title }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
        lineNumber: 52,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "place-card__type", children: offer.type }, void 0, false, {
        fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
}
_s(FavoriteCard, "6DR0ZGJGbR7YBKBB9MXuZ+Xxni4=", false, function() {
  return [useAppDispatch];
});
_c = FavoriteCard;
var _c;
$RefreshReg$(_c, "FavoriteCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/rubco/2346685-six-cities-4/src/components/cards/favorite/favorite-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZCVixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0Msb0NBQW9DO0FBQzdDLFNBQVNDLHNCQUFzQjtBQU0vQix3QkFBd0JDLGFBQWE7QUFBQSxFQUFFQztBQUEwQixHQUFnQjtBQUFBQyxLQUFBO0FBQy9FLFFBQU1DLFdBQVdKLGVBQWU7QUFDaEMsUUFBTSxDQUFDSyxpQkFBaUJDLGdCQUFnQixJQUFJUixTQUF5QkksTUFBTUssVUFBVTtBQUVyRixRQUFNQyw0QkFBNEJBLE1BQU07QUFDdENKLGFBQVNMLDZCQUE2QjtBQUFBLE1BQUNVLElBQUlQLE1BQU1PO0FBQUFBLE1BQUlDLGdCQUFnQixDQUFDTDtBQUFBQSxJQUFlLENBQUMsQ0FBQztBQUN2RkMscUJBQWlCLENBQUNELGVBQWU7QUFBQSxFQUNuQztBQUVBLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLDhCQUNqQjtBQUFBLDJCQUFDLFNBQUksV0FBVSxzREFDYixpQ0FBQyxRQUFLLElBQUssVUFBU0gsTUFBTU8sRUFBRyxJQUFHLE9BQU9QLE9BQ3JDLGlDQUFDLFNBQUksV0FBVSxxQkFBb0IsS0FBS0EsTUFBTVMsY0FBYyxPQUFNLE9BQU0sUUFBTyxPQUFNLEtBQUksaUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0csS0FEeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxZQUFPVCxNQUFNVTtBQUFBQSxlQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFELHVCQUFDLFVBQUssV0FBVSwwQkFBeUIsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsYUFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFdBQVksK0JBQThCUCxrQkFBa0Isd0NBQXdDLEVBQUcsV0FBVSxTQUFTRywyQkFBMkIsTUFBSyxVQUNoSztBQUFBLGlDQUFDLFNBQUksV0FBVSw2QkFBNEIsT0FBTSxNQUFLLFFBQU8sTUFDM0QsaUNBQUMsU0FBSSxXQUFVLG9CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxtQkFBa0IsNEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsYUFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSwrQkFBQyxVQUFLLE9BQU87QUFBQSxVQUFFSyxPQUFPaEIsbUJBQW1CSyxNQUFNWSxNQUFNO0FBQUEsUUFBRSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsVUFBSyxXQUFVLG1CQUFrQixzQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFdBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLG9CQUNaLGlDQUFDLFFBQUssSUFBSyxVQUFTWixNQUFNTyxFQUFHLElBQUcsT0FBT1AsT0FBUUEsZ0JBQU1hLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsb0JBQW9CYixnQkFBTWMsUUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLFNBdEI5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVKO0FBQUNiLEdBMUN1QkYsY0FBWTtBQUFBLFVBQ2pCRCxjQUFjO0FBQUE7QUFBQWlCLEtBRFRoQjtBQUFZLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTGluayIsImdldFN0YXJzRnJvbVJhdGluZyIsInVzZVN0YXRlIiwic2V0T2ZmZXJGYXZvcml0ZVN0YXR1c0FjdGlvbiIsInVzZUFwcERpc3BhdGNoIiwiRmF2b3JpdGVDYXJkIiwib2ZmZXIiLCJfcyIsImRpc3BhdGNoIiwiaXNGYXZvcml0ZU9mZmVyIiwic2V0RmF2b3JpdGVPZmZlciIsImlzRmF2b3JpdGUiLCJoYW5kbGVGYXZvcml0ZUJ1dHRvbkNsaWNrIiwiaWQiLCJmYXZvcml0ZVN0YXR1cyIsInByZXZpZXdJbWFnZSIsInByaWNlIiwid2lkdGgiLCJyYXRpbmciLCJ0aXRsZSIsInR5cGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImZhdm9yaXRlLWNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE9mZmVyVHlwZSB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50L3R5cGVzJztcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IGdldFN0YXJzRnJvbVJhdGluZyB9IGZyb20gJy4uLy4uLy4uL2NvbnN0YW50L3V0aWxzJztcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgc2V0T2ZmZXJGYXZvcml0ZVN0YXR1c0FjdGlvbiB9IGZyb20gJy4uLy4uLy4uL3N0b3JlL2FwaS1hY3Rpb25zJztcbmltcG9ydCB7IHVzZUFwcERpc3BhdGNoIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MnO1xuXG5leHBvcnQgdHlwZSBGYXZvcml0ZUNhcmRQYXJhbXMgPSB7XG4gIG9mZmVyOiBPZmZlclR5cGU7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZhdm9yaXRlQ2FyZCh7IG9mZmVyIH06IEZhdm9yaXRlQ2FyZFBhcmFtcyk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VBcHBEaXNwYXRjaCgpO1xuICBjb25zdCBbaXNGYXZvcml0ZU9mZmVyLCBzZXRGYXZvcml0ZU9mZmVyXSA9IHVzZVN0YXRlPGJvb2xlYW4gfCBudWxsPihvZmZlci5pc0Zhdm9yaXRlKTtcblxuICBjb25zdCBoYW5kbGVGYXZvcml0ZUJ1dHRvbkNsaWNrID0gKCkgPT4ge1xuICAgIGRpc3BhdGNoKHNldE9mZmVyRmF2b3JpdGVTdGF0dXNBY3Rpb24oe2lkOiBvZmZlci5pZCwgZmF2b3JpdGVTdGF0dXM6ICFpc0Zhdm9yaXRlT2ZmZXJ9KSk7XG4gICAgc2V0RmF2b3JpdGVPZmZlcighaXNGYXZvcml0ZU9mZmVyKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cImZhdm9yaXRlc19fY2FyZCBwbGFjZS1jYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZhdm9yaXRlc19faW1hZ2Utd3JhcHBlciBwbGFjZS1jYXJkX19pbWFnZS13cmFwcGVyXCI+XG4gICAgICAgIDxMaW5rIHRvPXtgL29mZmVyLyR7b2ZmZXIuaWR9YH0gc3RhdGU9e29mZmVyfT5cbiAgICAgICAgICA8aW1nIGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX2ltYWdlXCIgc3JjPXtvZmZlci5wcmV2aWV3SW1hZ2V9IHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjAwXCIgYWx0PVwiUGxhY2UgaW1hZ2VcIiAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmF2b3JpdGVzX19jYXJkLWluZm8gcGxhY2UtY2FyZF9faW5mb1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX3ByaWNlLXdyYXBwZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX3ByaWNlXCI+XG4gICAgICAgICAgICA8YiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19wcmljZS12YWx1ZVwiPiZldXJvO3tvZmZlci5wcmljZX08L2I+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19wcmljZS10ZXh0XCI+JiM0NzsmbmJzcDtuaWdodDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17YHBsYWNlLWNhcmRfX2Jvb2ttYXJrLWJ1dHRvbiAke2lzRmF2b3JpdGVPZmZlciA/ICdwbGFjZS1jYXJkX19ib29rbWFyay1idXR0b24tLWFjdGl2ZScgOiAnJ30gYnV0dG9uYH0gb25DbGljaz17aGFuZGxlRmF2b3JpdGVCdXR0b25DbGlja30gdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19ib29rbWFyay1pY29uXCIgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE5XCI+XG4gICAgICAgICAgICAgIDx1c2UgeGxpbmtIcmVmPVwiI2ljb24tYm9va21hcmtcIj48L3VzZT5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmlzdWFsbHktaGlkZGVuXCI+SW4gYm9va21hcmtzPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19yYXRpbmcgcmF0aW5nXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFjZS1jYXJkX19zdGFycyByYXRpbmdfX3N0YXJzXCI+XG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogZ2V0U3RhcnNGcm9tUmF0aW5nKG9mZmVyLnJhdGluZykgfX0+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmlzdWFsbHktaGlkZGVuXCI+UmF0aW5nPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInBsYWNlLWNhcmRfX25hbWVcIj5cbiAgICAgICAgICA8TGluayB0bz17YC9vZmZlci8ke29mZmVyLmlkfWB9IHN0YXRlPXtvZmZlcn0+e29mZmVyLnRpdGxlfTwvTGluaz5cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicGxhY2UtY2FyZF9fdHlwZVwiPntvZmZlci50eXBlfTwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvYXJ0aWNsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnViY28vMjM0NjY4NS1zaXgtY2l0aWVzLTQvc3JjL2NvbXBvbmVudHMvY2FyZHMvZmF2b3JpdGUvZmF2b3JpdGUtY2FyZC50c3gifQ==