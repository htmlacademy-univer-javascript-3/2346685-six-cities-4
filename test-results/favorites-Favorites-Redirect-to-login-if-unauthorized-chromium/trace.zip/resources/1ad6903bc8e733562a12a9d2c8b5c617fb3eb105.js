import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/hooks/use-map.tsx");import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/rubco/2346685-six-cities-4/src/hooks/use-map.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=010e9a4f"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"]; const useRef = __vite__cjsImport2_react["useRef"];
import __vite__cjsImport3_leaflet from "/node_modules/.vite/deps/leaflet.js?v=83d1217c"; const Map = __vite__cjsImport3_leaflet["Map"]; const TileLayer = __vite__cjsImport3_leaflet["TileLayer"];
export default function useMap(mapRef, location) {
  _s();
  const [map, setMap] = useState(null);
  const isRenderedRef = useRef(false);
  useEffect(() => {
    if (mapRef.current !== null && !isRenderedRef.current) {
      const instance = new Map(mapRef.current, {
        center: {
          lat: location.latitude,
          lng: location.longitude
        },
        zoom: location.zoom
      });
      const layer = new TileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      });
      instance.addLayer(layer);
      setMap(instance);
      isRenderedRef.current = true;
    }
  }, [mapRef, location]);
  return map;
}
_s(useMap, "ABu9tQwf43psTVyI2B0fPm/piwo=");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/rubco/2346685-six-cities-4/src/hooks/use-map.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVNBLFdBQVdDLFVBQTRCQyxjQUFjO0FBQzlELFNBQVNDLEtBQUtDLGlCQUFpQjtBQUcvQix3QkFBd0JDLE9BQ3RCQyxRQUNBQyxVQUNZO0FBQUFDLEtBQUE7QUFDWixRQUFNLENBQUNDLEtBQUtDLE1BQU0sSUFBSVQsU0FBcUIsSUFBSTtBQUMvQyxRQUFNVSxnQkFBZ0JULE9BQWdCLEtBQUs7QUFFM0NGLFlBQVUsTUFBTTtBQUNkLFFBQUlNLE9BQU9NLFlBQVksUUFBUSxDQUFDRCxjQUFjQyxTQUFTO0FBQ3JELFlBQU1DLFdBQVcsSUFBSVYsSUFBSUcsT0FBT00sU0FBUztBQUFBLFFBQ3ZDRSxRQUFRO0FBQUEsVUFDTkMsS0FBS1IsU0FBU1M7QUFBQUEsVUFDZEMsS0FBS1YsU0FBU1c7QUFBQUEsUUFDaEI7QUFBQSxRQUNBQyxNQUFNWixTQUFTWTtBQUFBQSxNQUNqQixDQUFDO0FBRUQsWUFBTUMsUUFBUSxJQUFJaEIsVUFDaEIsNEVBQ0E7QUFBQSxRQUNFaUIsYUFDRTtBQUFBLE1BQ0osQ0FDRjtBQUVBUixlQUFTUyxTQUFTRixLQUFLO0FBRXZCVixhQUFPRyxRQUFRO0FBQ2ZGLG9CQUFjQyxVQUFVO0FBQUEsSUFDMUI7QUFBQSxFQUNGLEdBQUcsQ0FBQ04sUUFBUUMsUUFBUSxDQUFDO0FBRXJCLFNBQU9FO0FBQ1Q7QUFBQ0QsR0FqQ3VCSCxRQUFNIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJNYXAiLCJUaWxlTGF5ZXIiLCJ1c2VNYXAiLCJtYXBSZWYiLCJsb2NhdGlvbiIsIl9zIiwibWFwIiwic2V0TWFwIiwiaXNSZW5kZXJlZFJlZiIsImN1cnJlbnQiLCJpbnN0YW5jZSIsImNlbnRlciIsImxhdCIsImxhdGl0dWRlIiwibG5nIiwibG9uZ2l0dWRlIiwiem9vbSIsImxheWVyIiwiYXR0cmlidXRpb24iLCJhZGRMYXllciJdLCJzb3VyY2VzIjpbInVzZS1tYXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIE11dGFibGVSZWZPYmplY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1hcCwgVGlsZUxheWVyIH0gZnJvbSAnbGVhZmxldCc7XG5pbXBvcnQgeyBMb2NhdGlvblR5cGUgfSBmcm9tICcuLi9jb25zdGFudC90eXBlcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHVzZU1hcChcbiAgbWFwUmVmOiBNdXRhYmxlUmVmT2JqZWN0PEhUTUxFbGVtZW50IHwgbnVsbD4sXG4gIGxvY2F0aW9uOiBMb2NhdGlvblR5cGVcbik6IE1hcCB8IG51bGwge1xuICBjb25zdCBbbWFwLCBzZXRNYXBdID0gdXNlU3RhdGU8TWFwIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGlzUmVuZGVyZWRSZWYgPSB1c2VSZWY8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKG1hcFJlZi5jdXJyZW50ICE9PSBudWxsICYmICFpc1JlbmRlcmVkUmVmLmN1cnJlbnQpIHtcbiAgICAgIGNvbnN0IGluc3RhbmNlID0gbmV3IE1hcChtYXBSZWYuY3VycmVudCwge1xuICAgICAgICBjZW50ZXI6IHtcbiAgICAgICAgICBsYXQ6IGxvY2F0aW9uLmxhdGl0dWRlLFxuICAgICAgICAgIGxuZzogbG9jYXRpb24ubG9uZ2l0dWRlLFxuICAgICAgICB9LFxuICAgICAgICB6b29tOiBsb2NhdGlvbi56b29tXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgbGF5ZXIgPSBuZXcgVGlsZUxheWVyKFxuICAgICAgICAnaHR0cHM6Ly97c30uYmFzZW1hcHMuY2FydG9jZG4uY29tL3Jhc3RlcnRpbGVzL3ZveWFnZXIve3p9L3t4fS97eX17cn0ucG5nJyxcbiAgICAgICAge1xuICAgICAgICAgIGF0dHJpYnV0aW9uOlxuICAgICAgICAgICAgJyZjb3B5OyA8YSBocmVmPVwiaHR0cHM6Ly93d3cub3BlbnN0cmVldG1hcC5vcmcvY29weXJpZ2h0XCI+T3BlblN0cmVldE1hcDwvYT4gY29udHJpYnV0b3JzICZjb3B5OyA8YSBocmVmPVwiaHR0cHM6Ly9jYXJ0by5jb20vYXR0cmlidXRpb25zXCI+Q0FSVE88L2E+J1xuICAgICAgICB9XG4gICAgICApO1xuXG4gICAgICBpbnN0YW5jZS5hZGRMYXllcihsYXllcik7XG5cbiAgICAgIHNldE1hcChpbnN0YW5jZSk7XG4gICAgICBpc1JlbmRlcmVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgfSwgW21hcFJlZiwgbG9jYXRpb25dKTtcblxuICByZXR1cm4gbWFwO1xufVxuIl0sImZpbGUiOiIvaG9tZS9ydWJjby8yMzQ2Njg1LXNpeC1jaXRpZXMtNC9zcmMvaG9va3MvdXNlLW1hcC50c3gifQ==